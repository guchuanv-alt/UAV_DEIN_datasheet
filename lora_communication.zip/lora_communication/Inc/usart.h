#ifndef __USART_H__
#define __USART_H__


#include "sys.h"

void MX_USART_Init(void);
void Print(uint8_t data[],uint16_t len);    //��ӡ��Ϣ
void USART2_IRQHandler(void);

#endif // 



