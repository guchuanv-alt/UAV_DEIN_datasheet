#ifndef __MAIN_H__
#define __MAIN_H__

	#include "stm32l4xx_hal.h"
	#include "stm32l4xx.h"
	#include "cmsis_os.h"
	#include <string.h>
    #include <stdbool.h>

	#define IRQ_DISABLE() (__disable_irq())
	#define IRQ_ENABLE()  (__enable_irq())
	

#endif
