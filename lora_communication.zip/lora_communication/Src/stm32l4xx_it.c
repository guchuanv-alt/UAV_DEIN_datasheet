#include "stm32l4xx_hal.h"
#include "stm32l4xx.h"
#include "cmsis_os.h"

void NMI_Handler(void)
{
	while (1)
	{
	}
}

void HardFault_Handler(void)
{
	while (1)
	{
	}
}

void MemManage_Handler(void)
{
	while (1)
	{
	}
}

void BusFault_Handler(void)
{
	while (1)
	{
	}
}

void UsageFault_Handler(void)
{
	while (1)
	{
	}
}

void DebugMon_Handler(void)
{
	while (1)
	{
	}
}

void PVD_IRQHandler(void)
{
	while (1)
	{
	}
}

void SysTick_Handler(void)
{
    HAL_IncTick();
    osSystickHandler();
}
