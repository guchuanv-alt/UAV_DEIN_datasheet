#include "spi.h"


SPI_HandleTypeDef 			hspi1;
SPI_HandleTypeDef 			hspi2;

void MX_MCU_SPI_INIT(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
//SPI1��ʼ��
	__HAL_RCC_GPIOA_CLK_ENABLE( );
	GPIO_InitStructure.Pin 			= GPIO_PIN_4;
	GPIO_InitStructure.Pull 		= GPIO_PULLUP;
	GPIO_InitStructure.Mode 		= GPIO_MODE_OUTPUT_PP;
	GPIO_InitStructure.Speed 		= GPIO_SPEED_HIGH;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStructure );
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_SET);
	
	GPIO_InitStructure.Pin 			= GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
    GPIO_InitStructure.Mode 		= GPIO_MODE_AF_PP;
    GPIO_InitStructure.Pull 		= GPIO_NOPULL;
    GPIO_InitStructure.Speed 		= GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStructure.Alternate 	= GPIO_AF5_SPI1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStructure);

	__HAL_RCC_SPI1_CLK_ENABLE();
	hspi1.Instance 					= SPI1;
	hspi1.Init.Mode 					= SPI_MODE_MASTER;
	hspi1.Init.Direction 			= SPI_DIRECTION_2LINES;
	hspi1.Init.DataSize 				= SPI_DATASIZE_8BIT;
	hspi1.Init.CLKPolarity 			= SPI_POLARITY_LOW;
	hspi1.Init.CLKPhase 				= SPI_PHASE_1EDGE;
	hspi1.Init.NSS 					= SPI_NSS_SOFT;
	hspi1.Init.BaudRatePrescaler  	= SPI_BAUDRATEPRESCALER_4;
	hspi1.Init.FirstBit 				= SPI_FIRSTBIT_MSB;
	hspi1.Init.TIMode 				= SPI_TIMODE_DISABLE;
	hspi1.Init.CRCCalculation 		= SPI_CRCCALCULATION_DISABLE;
	hspi1.Init.CRCPolynomial 		= 7;

	HAL_SPI_Init(&hspi1);
    __HAL_SPI_ENABLE(&hspi1);
//SPI2��ʼ��	
	__HAL_RCC_GPIOA_CLK_ENABLE( );
	GPIO_InitStructure.Pin 			= GPIO_PIN_12;
	GPIO_InitStructure.Pull 		= GPIO_PULLUP;
	GPIO_InitStructure.Mode 		= GPIO_MODE_OUTPUT_PP;
	GPIO_InitStructure.Speed 		= GPIO_SPEED_HIGH;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStructure );
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
	
	GPIO_InitStructure.Pin 			= GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
    GPIO_InitStructure.Mode 		= GPIO_MODE_AF_PP;
    GPIO_InitStructure.Pull 		= GPIO_NOPULL;
    GPIO_InitStructure.Speed 		= GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStructure.Alternate 	= GPIO_AF5_SPI2;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStructure);

	__HAL_RCC_SPI1_CLK_ENABLE();
	hspi2.Instance 					= SPI2;
	hspi2.Init.Mode 					= SPI_MODE_MASTER;
	hspi2.Init.Direction 			= SPI_DIRECTION_2LINES;
	hspi2.Init.DataSize 				= SPI_DATASIZE_8BIT;
	hspi2.Init.CLKPolarity 			= SPI_POLARITY_LOW;
	hspi2.Init.CLKPhase 				= SPI_PHASE_1EDGE;
	hspi2.Init.NSS 					= SPI_NSS_SOFT;
	hspi2.Init.BaudRatePrescaler  	= SPI_BAUDRATEPRESCALER_4;
	hspi2.Init.FirstBit 				= SPI_FIRSTBIT_MSB;
	hspi2.Init.TIMode 				= SPI_TIMODE_DISABLE;
	hspi2.Init.CRCCalculation 		= SPI_CRCCALCULATION_DISABLE;
	hspi2.Init.CRCPolynomial 		= 7;

	HAL_SPI_Init(&hspi2);
    __HAL_SPI_ENABLE(&hspi2);
}
void MX_MCU_SPI_DEINIT(void)
{
	HAL_SPI_DeInit(&hspi1);
  __HAL_RCC_SPI1_CLK_DISABLE();
  HAL_GPIO_DeInit(GPIOA, GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7);
		HAL_SPI_DeInit(&hspi2);
  __HAL_RCC_SPI2_CLK_DISABLE();
  HAL_GPIO_DeInit(GPIOB, GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15);
} 

