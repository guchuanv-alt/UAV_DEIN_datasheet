#ifndef __SYS_H__
#define __SYS_H__

#include "stm32l4xx_hal.h"
#include "stm32l4xx.h"
#include "cmsis_os.h"
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdbool.h>

	#define IRQ_DISABLE() (__disable_irq())
	#define IRQ_ENABLE()  (__enable_irq())


void SystemClock_Config(void);   //ϵͳʱ�ӳ�ʼ��//
void RTC_Init(void);
void Set_Initial_RTC_DateTime(void);   //����RTC��ʼʱ��

void Get_Timestamp(RTC_TimeTypeDef *time, RTC_DateTypeDef *date);     // ��ȡ��ǰʱ���


#endif // 



