#include "usart.h"


UART_HandleTypeDef      huart2;
UART_HandleTypeDef      huart1;
extern TaskHandle_t Lora_Tx_Handle;
extern uint8_t resume;
//����1��ӡ��Ϣ������2����4Gģ��
//�ض���fputc���� 
int fputc(int ch, FILE *f)
{
    // Wait until the transmit data register is empty
    while (!(USART2->ISR & USART_ISR_TXE)) {}

    // Send the character
    USART2->TDR = (uint8_t)ch;

    return ch;
}

/**���ص��Դ���USART2����ʼ��**/
void MX_USART_Init(void)
{
	GPIO_InitTypeDef 	GPIO_InitStruct;
	__HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	__HAL_RCC_USART2_CLK_ENABLE();
	huart2.Instance = USART2;
	huart2.Init.BaudRate = 9600;
	huart2.Init.WordLength = UART_WORDLENGTH_8B;
	huart2.Init.StopBits = UART_STOPBITS_1;
	huart2.Init.Parity = UART_PARITY_NONE;
	huart2.Init.Mode = UART_MODE_TX_RX;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	HAL_UART_Init(&huart2);
    
    HAL_NVIC_SetPriority(USART2_IRQn, 10, 10);
    HAL_NVIC_EnableIRQ(USART2_IRQn);
	__HAL_UART_ENABLE_IT(&huart2,UART_IT_RXNE);	
	
	
	__HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	__HAL_RCC_USART1_CLK_ENABLE();
	huart1.Instance = USART1;
	huart1.Init.BaudRate = 115200;
	huart1.Init.WordLength = UART_WORDLENGTH_8B;
	huart1.Init.StopBits = UART_STOPBITS_1;
	huart1.Init.Parity = UART_PARITY_NONE;
	huart1.Init.Mode = UART_MODE_TX_RX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart1.Init.OverSampling = UART_OVERSAMPLING_16;
	huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	HAL_UART_Init(&huart1);
    
    // HAL_NVIC_SetPriority(USART1_IRQn, 10, 10);
    // HAL_NVIC_EnableIRQ(USART1_IRQn);
	// __HAL_UART_ENABLE_IT(&huart1,UART_IT_RXNE);	
}
/**��ӡ��Ϣ**/
void Print(uint8_t data[],uint16_t len)
{
	uint16_t i;
	
	for(i=0;i<len;i++)
	{
		while((__HAL_UART_GET_FLAG((&huart2),UART_FLAG_TXE)?SET:RESET) == RESET);
		(&huart2)->Instance->TDR =data[i];
	}
}
/**���ڽ����ж�**/
void USART1_IRQHandler(void)
{
	char tmp1_char;
	
	if(__HAL_UART_GET_FLAG((&huart1),USART_ISR_RXNE) != RESET)
	{
		tmp1_char =  READ_REG((&huart1)->Instance->RDR);
		///self process
		if(tmp1_char==1){
			resume=1;
			tmp1_char=0;
		}
	}
	__HAL_UART_CLEAR_FLAG((&huart1),USART_ISR_PE|USART_ISR_FE|USART_ISR_NE|USART_ISR_ORE);
	
}

void USART2_IRQHandler(void)                	//�����жϷ������
	{
		char tmp2_char=0;

	if(__HAL_UART_GET_FLAG((&huart2),USART_ISR_RXNE) != RESET)  //�����ж�
		{
			tmp2_char =  READ_REG((&huart2)->Instance->RDR);

     } 
	__HAL_UART_CLEAR_FLAG((&huart2),USART_ISR_PE|USART_ISR_FE|USART_ISR_NE|USART_ISR_ORE);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
	if(huart->Instance==USART1){
		
	}
}

