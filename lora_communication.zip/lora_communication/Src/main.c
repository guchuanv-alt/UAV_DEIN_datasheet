/**
MCU说明，STM32L431CBT6: 
主频最高80MHz
128K FLASH
64K RAM
38个GPIO
3路USART
3路SPI
3路I2C
1路CAN
多通道ADC
多路TIM定时器
自带IWDG看门狗
			
HSE:16MHz        
LSE:32.768KHz

PA2:USART2_TX    本地调试串口
PA3:USART2_RX
**/
/**
SX1278与MCU相连，引脚说明：
SX1278 <---> MCU
DIO0     -   PB0
DIO1     -   PB1
NRESET   -   PC13

NSS      -   PA4
SCK      -   PA5
MISO     -   PA6
MOSI     -   PA7
**/
#include "sys.h"
#include "sx126x.h"
#include "spi.h"
#include "usart.h"
#include "gpio.h"
#include "radio.h"
#include "mytask.h"
uint32_t R[113];            //定义LMX2594寄存器数组
extern RTC_TimeTypeDef currentTime;
extern RTC_DateTypeDef currentDate;
extern uint8_t RadioRxPayload[];
extern uint8_t Radiosize;
extern int8_t  Radiorssi;
extern int8_t  Radiosnr;
 /* 创建任务句柄 */
TaskHandle_t TaskInit_Handle = NULL;    //任务初始化任务句柄
LoRaMacMessageData_t   syn_msg;

/**main函数**/
int main(void)
{
	HAL_Init();
	SystemClock_Config();
//	RTC_Init();  // 初始化RTC
//	Set_Initial_RTC_DateTime(); //初始化RTC时钟
  MX_USART_Init();
	printf("\r\nsystem start...\r\n");
	MX_GPIO_INIT();
	SX126xInit();
	BaseType_t xReturn = pdPASS;/* 定义一个创建信息返回值，默认为pdPASS */


   /* 创建TaskInitTaskCreate任务 */
  xReturn = xTaskCreate((TaskFunction_t )TaskInitTask,  /* 任务入口函数 */
                        (const char*    )"TaskInit",/* 任务名字 */
                        (uint16_t       )TaskInit_STK_SIZE,  /* 任务栈大小 */
                        (void*          )NULL,/* 任务入口函数参数 */
                        (UBaseType_t    )TaskInit_PRIO, /* 任务的优先级 */
                        (TaskHandle_t*  )&TaskInit_Handle);/* 任务控制块指针 */ 
  /* 启动任务调度 */           
  if(pdPASS == xReturn)
    vTaskStartScheduler();   /* 启动任务，开启调度 */
  else
    return -1;  
	
	
	while (1)
	{
	}
}
