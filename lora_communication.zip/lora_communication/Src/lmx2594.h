#ifndef __LMX2594_H
#define	__LMX2594_H
#include "stm32l4xx_hal.h"
#include "stm32l4xx.h"

																
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 
#define GPIO_ODR_OFFSET   0x14
#define GPIO_IDR_OFFSET   0x10

//IO�ڵ�ַӳ��
#define GPIOA_ODR_Addr    (GPIOA_BASE+GPIO_ODR_OFFSET) 
#define GPIOB_ODR_Addr    (GPIOB_BASE+GPIO_ODR_OFFSET) 
#define GPIOC_ODR_Addr    (GPIOC_BASE+GPIO_ODR_OFFSET) 
//#define GPIOD_ODR_Addr    (GPIOD_BASE+GPIO_ODR_OFFSET) 
//#define GPIOE_ODR_Addr    (GPIOE_BASE+GPIO_ODR_OFFSET) 
//#define GPIOF_ODR_Addr    (GPIOF_BASE+GPIO_ODR_OFFSET) 
//#define GPIOG_ODR_Addr    (GPIOG_BASE+GPIO_ODR_OFFSET)     

#define GPIOA_IDR_Addr    (GPIOA_BASE+GPIO_IDR_OFFSET) //0x40010808 
#define GPIOB_IDR_Addr    (GPIOB_BASE+GPIO_IDR_OFFSET) //0x40010C08 
#define GPIOC_IDR_Addr    (GPIOC_BASE+GPIO_IDR_OFFSET) //0x40011008 
//#define GPIOD_IDR_Addr    (GPIOD_BASE+GPIO_IDR_OFFSET) //0x40011408 
//#define GPIOE_IDR_Addr    (GPIOE_BASE+GPIO_IDR_OFFSET) //0x40011808 
//#define GPIOF_IDR_Addr    (GPIOF_BASE+GPIO_IDR_OFFSET) //0x40011A08 
//#define GPIOG_IDR_Addr    (GPIOG_BASE+GPIO_IDR_OFFSET) //0x40011E08 
 
//IO�ڲ���,ֻ�Ե�һ��IO��!
//ȷ��n��ֵС��16!
#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr,n)  //��� 
#define PAin(n)    BIT_ADDR(GPIOA_IDR_Addr,n)  //���� 

#define PBout(n)   BIT_ADDR(GPIOB_ODR_Addr,n)  //��� 
#define PBin(n)    BIT_ADDR(GPIOB_IDR_Addr,n)  //���� 

#define PCout(n)   BIT_ADDR(GPIOC_ODR_Addr,n)  //��� 
#define PCin(n)    BIT_ADDR(GPIOC_IDR_Addr,n)  //���� 

//#define I2C_SCL_HIGH() HAL_GPIO_WritePin(I2C_PORT, I2C_SCL_PIN, GPIO_PIN_SET)
//#define I2C_SCL_LOW() HAL_GPIO_WritePin(I2C_PORT, I2C_SCL_PIN, GPIO_PIN_RESET)
//#define I2C_SDA_HIGH() HAL_GPIO_WritePin(I2C_PORT, I2C_SDA_PIN, GPIO_PIN_SET)
//#define I2C_SDA_LOW() HAL_GPIO_WritePin(I2C_PORT, I2C_SDA_PIN, GPIO_PIN_RESET)
//#define I2C_SDA_READ() HAL_GPIO_ReadPin(I2C_PORT, I2C_SDA_PIN)


//#define SDA_IN()  {GPIO_InitStructinout.Pin = GPIO_PIN_7;GPIO_InitStructinout.Mode = GPIO_MODE_INPUT;GPIO_InitStructinout.Pull = GPIO_NOPULL;HAL_GPIO_Init(GPIOB, &GPIO_InitStructinout);}
//#define SDA_OUT() {GPIO_InitStructinout.Pin = GPIO_PIN_7;GPIO_InitStructinout.Mode = GPIO_MODE_OUTPUT_PP;GPIO_InitStructinout.Pull = GPIO_NOPULL;HAL_GPIO_Init(GPIOB, &GPIO_InitStructinout);}



#define LMX2594_CLK 	PAout(6)
#define LMX2594_LE 		PAout(2)
#define LMX2594_DATA 	PAout(3)
#define LMX2594_CE 		PAout(1)
#define LMX2594_MUX 	PAin(7)

				
void SendData(uint32_t a);					//����д�����ֳ���
void Lmx2594_GPIO_Config(void);			//д���������ų�ʼ������
void Frequencyfixed(uint32_t f1, uint32_t t1);
void Frequencysweep(uint32_t f1, uint32_t f2, uint32_t t1, uint32_t d1);
void Frequencyhopping(uint32_t f1, uint32_t f2,uint32_t t1, uint32_t d1);
void SendDataArray(uint32_t *a, uint32_t num);
//void mode1(uint32_t starthz, uint32_t stophz, uint32_t stephz);

#endif /* __LMX2594_H */

