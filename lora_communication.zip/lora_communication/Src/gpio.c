#include "gpio.h"



void MX_GPIO_INIT(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	///LED
	__HAL_RCC_GPIOB_CLK_ENABLE( );
	GPIO_InitStructure.Pin 		= GPIO_PIN_8;	
	GPIO_InitStructure.Pull 	= GPIO_PULLUP;
	GPIO_InitStructure.Mode 	= GPIO_MODE_OUTPUT_PP;
	GPIO_InitStructure.Speed 	= GPIO_SPEED_HIGH;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStructure );
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_8,GPIO_PIN_RESET);
}


