#ifndef __RADIO_H__
#define __RADIO_H__
#include "sys.h"
#include <stdio.h>
#include <stdlib.h>
///����ƽ����뷢�ͣ���ע�͵�����Ϊ����ģʽ
//#define RX_MODULE
#define FREQ_OF_TEST  475300000    ///Ƶ��
#define PWR_OF_TEST   17           ///-9  ~  22 
#define DR_OF_TEST    12            ///5  ~  12





	typedef struct
	{
		uint8_t tx_done_flag;
		uint8_t tx_timeout_flag;
		uint8_t rx_timeout_flag;
		uint8_t rx_error_flag;
		uint8_t rx_done_flag;
	}LORA_STATUS_T;
	
void MX_SX126X_GPIO_INIT(void);
void MX_SX126X_RESET( void );
uint8_t MX_SX126X_SPI_WRITE_READ(uint8_t data_in);
void MX_SX126X_CS_HIGH(void);
void MX_SX126X_CS_LOW(void);
void LoraTxDoneCallback(void);
void LoraTxTimeoutCallback(void);
///���ճ�ʱ
void LoraRxTimeoutCallback(void);
void LoraRxErrorCallback(void);
///�������
void LoraRxDoneCallback(void);
void LoraCadDoneCallback(void);
void LoraRxParaSet( uint32_t rx_freq,uint8_t dr);
void StackTxParaSet(uint32_t tx_freq,int8_t tx_pwr,uint8_t tx_dr);
void fillRadioPayload( RTC_TimeTypeDef *currentTime,   RTC_DateTypeDef *currentDate) ;


#endif // __RADIO_H__


