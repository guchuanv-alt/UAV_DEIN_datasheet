/** @file STM32_timer_interrupt_lib.c
 *  @brief Library layer for the STM32L4.
 *
 *  This file contains the applications' library abstraction layer, wrapping
 *  the driver layer functions which are vendor specific. Aims at making
 *  the code more portable.
 *  @bug No known bugs.
 */

#include "Timer.h"
#include "tim.h"

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim6;

int TIM2_COUNTER_FLAG=0;
int TIM1_COUNTER_FLAG=0;
int TIM2_60s_FLAG=0;
int Count_Start=0;
int Join_Over=0;
int ustime_cnt=0;
void Error_Handler(void){
  /* User can add his own implementation to report the HAL error return state */
//	__disable_irq();
	printf("TIMER INIT ERROR\r\n");
}

void init_tim1(uint32_t prescaler, uint32_t cnt_mode, uint32_t period,
				uint32_t clk_div, uint32_t rep_cnt, uint32_t auto_re_pre)
{
	TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	TIM_MasterConfigTypeDef sMasterConfig = {0};

	htim1.Instance = TIM1;
	htim1.Init.Prescaler = prescaler;
	htim1.Init.CounterMode = cnt_mode;
	htim1.Init.Period = period;
	htim1.Init.ClockDivision = clk_div;
	htim1.Init.RepetitionCounter = rep_cnt;
	htim1.Init.AutoReloadPreload = auto_re_pre;
	if (HAL_TIM_Base_Init(&htim1) != HAL_OK){
	Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK){
	Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK){
	Error_Handler();
	}
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @return None
  */
void init_tim2(uint32_t prescaler, uint32_t cnt_mode, uint32_t period,
		uint32_t clk_div, uint32_t auto_re_pre)
{
	TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	TIM_MasterConfigTypeDef sMasterConfig = {0};

	htim2.Instance = TIM2;
	htim2.Init.Prescaler = prescaler;
	htim2.Init.CounterMode = cnt_mode;
	htim2.Init.Period = period;
	htim2.Init.ClockDivision = clk_div;
	htim2.Init.AutoReloadPreload = auto_re_pre;
	if (HAL_TIM_Base_Init(&htim2) != HAL_OK){
	Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK){
	Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK){
	Error_Handler();
	}

}
void TIM6_Init(void)
{
    TIM_ClockConfigTypeDef sClockSourceConfig = {0};
    TIM_MasterConfigTypeDef sMasterConfig = {0};

    htim6.Instance = TIM6;
    htim6.Init.Prescaler = 80 - 1; // Ԥ��Ƶ������Ϊ1MHz
    htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim6.Init.Period = 0xFFFF; // �������
    htim6.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
    {
        Error_Handler();
    }

    sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
    if (HAL_TIM_ConfigClockSource(&htim6, &sClockSourceConfig) != HAL_OK)
    {
        Error_Handler();
    }

    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
    {
        Error_Handler();
    }
}
void tim_base_start_interrupt(void)
{
	HAL_TIM_Base_Start_IT(&htim1);
	HAL_TIM_Base_Start_IT(&htim2);
}

/** @brief Period elapsed callback in non-blocking mode,
 * 		toggles LED GREEN and RED.
 *
 * @param htim TIM handle
 * @return None
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef* htim)
{
	int cnt=0;
	if(htim->Instance == TIM2){
		//-------------TIM2 interupt function1-----------//

	}
	else if(htim->Instance == TIM1){
		//-------------TIM1 interupt function1-----------//
	}

}

void init_timer(void)
{
		init_tim1(39999, TIM_COUNTERMODE_UP, 1999, TIM_CLOCKDIVISION_DIV1,
		0, TIM_AUTORELOAD_PRELOAD_DISABLE); //main freq:80MHz TIM1 80000000/40000/2000=1Hz(1s onetime)
		init_tim2(39999, TIM_COUNTERMODE_UP, 1, TIM_CLOCKDIVISION_DIV1,
		TIM_AUTORELOAD_PRELOAD_DISABLE);//main freq:80MHz TIM2 80000000/400/200=1000Hz(0.001s onetime)
		tim_base_start_interrupt();
}
