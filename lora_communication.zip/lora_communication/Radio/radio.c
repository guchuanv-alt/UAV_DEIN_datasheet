#include "sys.h"
#include "radio.h"
#include "sx126x.h"


LORA_STATUS_T						lora_status;
#define RadioTxPayloadSize 50
uint8_t RadioTxPayload[RadioTxPayloadSize];

typedef enum
{
    Not_Send = 0,
    Start_Send,
	Stop_Send,
}downlink_satuts;
downlink_satuts Downlink_Satuts = Not_Send;

uint8_t rec_dtype;
uint8_t trans_dtype;
extern uint8_t RadioRxPayload[];
extern uint8_t Radiosize;
extern int8_t  Radiorssi;
extern int8_t  Radiosnr;
extern TaskHandle_t Lora_Tx_Handle;
extern TaskHandle_t Lora_Rx_Handle;
extern TaskHandle_t RtcTest_Handle;
extern TaskHandle_t Debug_Handle;
extern RTC_TimeTypeDef currentTime;
extern RTC_DateTypeDef currentDate;
RTC_TimeTypeDef testTime;
RTC_DateTypeDef testDate;
extern UART_HandleTypeDef huart1;

uint8_t flag=0;

/**SX127X驱动代码开始**/
void MX_SX126X_GPIO_INIT(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	 
	__HAL_RCC_GPIOB_CLK_ENABLE( );
	GPIO_InitStructure.Pin  		= GPIO_PIN_0;	///DIO0
    GPIO_InitStructure.Pull 		= GPIO_NOPULL;
	GPIO_InitStructure.Mode 		= GPIO_MODE_IT_RISING;
	GPIO_InitStructure.Speed 		= GPIO_SPEED_HIGH;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStructure );
	
	HAL_NVIC_SetPriority(EXTI0_IRQn, 6, 0);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
	
	GPIO_InitStructure.Pin 		= GPIO_PIN_1;	///DIO1
	GPIO_InitStructure.Pull 	= GPIO_PULLUP;
	GPIO_InitStructure.Mode 	= GPIO_MODE_OUTPUT_PP;
	GPIO_InitStructure.Speed 	= GPIO_SPEED_HIGH;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStructure );
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,GPIO_PIN_RESET);
	
	///DIO8,busy检测
	__HAL_RCC_GPIOA_CLK_ENABLE( );
	GPIO_InitStructure.Pin 		= GPIO_PIN_8;	
	GPIO_InitStructure.Pull 	= GPIO_PULLUP;
	GPIO_InitStructure.Mode 	= GPIO_MODE_INPUT;
	GPIO_InitStructure.Speed 	= GPIO_SPEED_HIGH;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStructure );
	
	
}
void MX_SX126X_RESET( void )
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	__HAL_RCC_GPIOC_CLK_ENABLE( );
	GPIO_InitStructure.Pin 		= GPIO_PIN_13;	
	GPIO_InitStructure.Pull 	= GPIO_PULLUP;
	GPIO_InitStructure.Mode 	= GPIO_MODE_OUTPUT_PP;
	GPIO_InitStructure.Speed 	= GPIO_SPEED_HIGH;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStructure );
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_13,GPIO_PIN_SET);
	HAL_Delay( 10 );
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_13,GPIO_PIN_RESET);
	HAL_Delay( 20 );
    HAL_GPIO_WritePin(GPIOC,GPIO_PIN_13,GPIO_PIN_SET);
    HAL_Delay( 10);
}
uint8_t MX_SX126X_SPI_WRITE_READ(uint8_t data_in)
{
    uint8_t data_out;
	
	IRQ_DISABLE();
    while((SPI1->SR & SPI_FLAG_TXE ) == RESET );
    *(__IO uint8_t *)&SPI1->DR = data_in;
	while((SPI1->SR & SPI_FLAG_RXNE ) == RESET );
    data_out = *(__IO uint8_t *)& SPI1->DR;
	IRQ_ENABLE();
	
    return( data_out );
}
void MX_SX126X_CS_LOW(void)
{
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_RESET);
}
void MX_SX126X_CS_HIGH(void)
{
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_SET);
}



///发送完成
void LoraTxDoneCallback(void)
{
	lora_status.tx_done_flag 		= true;
	flag=1;
}
void LoraTxTimeoutCallback(void)
{	
	lora_status.tx_timeout_flag 	= true;
}
///接收超时
void LoraRxTimeoutCallback(void)
{	
	lora_status.rx_timeout_flag 	= true;
}
void LoraRxErrorCallback(void)
{
	lora_status.rx_error_flag 	= true;
}
///接收完成中断函数
void LoraRxDoneCallback(void)
{
	lora_status.rx_done_flag  		= true;

	//The lora receive interrupt callback function, HERE!
	if(RadioRxPayload[0]==1){
		uint8_t transmit=1;
		HAL_UART_Transmit_IT(&huart1,&transmit,1);//Send the command to the PLL controller MCU to start emitting
	}
}
void LoraCadDoneCallback(void)
{
	
}
/**
Lora接收模块，参数设置
freq = 470~510MHz,频点
dr   = 5,6,7,8,9,10,11,12，对应着SF5 - SF12，SF7。其中SF5，速率最快

发送流程，函数调用说明：
1)设置接收频点；
2)设置接收最大字节数；
3)设置LoRa接收参数；
4)开启接收，并等待接收到数据包；
5)接收完成，引脚中断MCU；
6)读取数据包并解析；
7)设置模块休眠；
8)重复过程1~7。
**/
void LoraRxParaSet( uint32_t rx_freq,uint8_t dr)
{
	uint16_t symb_timeout = 10;  
	
	lora_status.rx_done_flag = false;
	lora_status.rx_timeout_flag = false;
	///设置频点
	SX126xSetRfFrequency( rx_freq );
	
	RadioSetRxConfig( 	MODEM_LORA, 
						0, 
						dr, 
						1, 
						0, 
						8, 
						symb_timeout, 
						false, 
						0, 
						false, 
						0, 
						0, 
						false,
						true );///rx continue mode
	RadioSetMaxPayloadLength(255);
	///开启接收
	RadioRx(0);	
	while((!lora_status.rx_done_flag) && (!lora_status.rx_timeout_flag));

	//接收到的值存在RadioRxPayload变量里？待验证。观察到接收是中断形式，在EXTI0中断EXTI0_IRQHandler里
	//Take a look at the comment above and verify the send and receive process

	//处理接收到的数据


}
/**
Lora发送模块，参数设置
freq = 470~510MHz,频点
pwr  = -9 ~ 22,数值越大，发射功率越大
dr   = 5,6,7,8,9,10,11,12，对应着SF5 - SF12，SF7。其中SF5，速率最快

发送流程，函数调用说明：
1)准备发送的数据；
2)设置最大发送字节数；
3)设置LoRa发送参数；
4)准备发送的频点；
5)开启发送；
6)等待发送完成，引脚中断MCU；
7)发送完成；
8)重复过程1~7。
**/
void StackTxParaSet(uint32_t tx_freq,int8_t tx_pwr,uint8_t tx_dr)
{
	lora_status.tx_done_flag = false;
	uint8_t txlength=4;
	SX126xSetRfFrequency( tx_freq );
	
	RadioSetTxConfig(MODEM_LORA,
					  tx_pwr, 
					  0, 
					  0, 
					  tx_dr, 
					  1, 
					  8, 
					  false, 
					  true, 
					  0, 
					  0, 
					  false, 
					  3000);
	///启动发射
	switch(Downlink_Satuts)
	{
		case Start_Send:
			RadioTxPayload[0] = 0x01;
			printf("TX完成，控制开启上行:");
			break;
		case Stop_Send:
			RadioTxPayload[0] = 0x02;
			printf("TX完成，控制关闭上行:");
			break;			
		default:
			break;
	
	}
	txlength=3;
	RadioSetMaxPayloadLength(txlength);
	RadioSend(RadioTxPayload,txlength);
	while(!lora_status.tx_done_flag);	
//	vTaskResume(Lora_Rx_Handle);    
//	vTaskSuspend(Lora_Tx_Handle);						
}