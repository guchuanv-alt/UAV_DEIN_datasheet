#ifndef __i2c_H
#define __i2c_H

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "uart.h"
#include "delay.h"
/* USER CODE BEGIN Includes */
// ���� I2C ���ߵ�����
#define I2C_SCL_PIN GPIO_PIN_6
#define I2C_SDA_PIN GPIO_PIN_7
#define I2C_PORT GPIOB

// ���� I2C ���ߵĿ��ƺ�
#define I2C_SCL_HIGH() HAL_GPIO_WritePin(I2C_PORT, I2C_SCL_PIN, GPIO_PIN_SET)
#define I2C_SCL_LOW() HAL_GPIO_WritePin(I2C_PORT, I2C_SCL_PIN, GPIO_PIN_RESET)
#define I2C_SDA_HIGH() HAL_GPIO_WritePin(I2C_PORT, I2C_SDA_PIN, GPIO_PIN_SET)
#define I2C_SDA_LOW() HAL_GPIO_WritePin(I2C_PORT, I2C_SDA_PIN, GPIO_PIN_RESET)
#define I2C_SDA_READ() HAL_GPIO_ReadPin(I2C_PORT, I2C_SDA_PIN)
/* USER CODE END Includes */

extern I2C_HandleTypeDef hi2c1;

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */
void MX_I2C1_Init(void);
void I2C1_GPIO_Init(I2C_HandleTypeDef* i2cHandle);
void I2C_Read(uint8_t dev_addr, uint8_t reg_addr, uint8_t *data, uint16_t size);
void I2C_Write(uint8_t dev_addr, uint8_t reg_addr, uint8_t *data, uint16_t size);
void MX_GPIOI2C_Init(void);

#define SDA_IN()  {GPIO_InitStructinout.Pin = GPIO_PIN_7;GPIO_InitStructinout.Mode = GPIO_MODE_INPUT;GPIO_InitStructinout.Pull = GPIO_NOPULL;HAL_GPIO_Init(GPIOB, &GPIO_InitStructinout);}
#define SDA_OUT() {GPIO_InitStructinout.Pin = GPIO_PIN_7;GPIO_InitStructinout.Mode = GPIO_MODE_OUTPUT_PP;GPIO_InitStructinout.Pull = GPIO_NOPULL;HAL_GPIO_Init(GPIOB, &GPIO_InitStructinout);}


//IIC���в�������
void IIC_Init(void);                //��ʼ��IIC��IO��				 
int IIC_Start(void);				//����IIC��ʼ�ź�
void IIC_Stop(void);	  			//����IICֹͣ�ź�
void IIC_Send_Byte(uint8_t txd);			//IIC����һ���ֽ�
uint8_t IIC_Read_Byte(unsigned char ack);//IIC��ȡһ���ֽ�
int IIC_Wait_Ack(void); 				//IIC�ȴ�ACK�ź�
void IIC_Ack(void);					//IIC����ACK�ź�
void IIC_NAck(void);				//IIC������ACK�ź�

void IIC_Write_One_Byte(uint8_t daddr,uint8_t addr,uint8_t data);
uint8_t IIC_Read_One_Byte(uint8_t daddr,uint8_t addr);	 
unsigned char I2C_Readkey(unsigned char I2C_Addr);

unsigned char I2C_ReadOneByte(unsigned char I2C_Addr,unsigned char addr);
unsigned char IICwriteByte(unsigned char dev, unsigned char reg, unsigned char data);
uint8_t IICwriteBytes(uint8_t dev, uint8_t reg, uint8_t length, uint8_t* data);
uint8_t IICwriteBits(uint8_t dev,uint8_t reg,uint8_t bitStart,uint8_t length,uint8_t data);
uint8_t IICwriteBit(uint8_t dev,uint8_t reg,uint8_t bitNum,uint8_t data);
uint8_t IICreadBytes(uint8_t dev, uint8_t reg, uint8_t length, uint8_t *data);

int i2cWrite(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *data);
int i2cRead(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *buf);

#endif /*__ i2c_H */

