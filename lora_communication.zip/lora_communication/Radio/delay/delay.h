#ifndef __DELAY_H__
#define __DELAY_H__
#include "stm32l4xx_hal.h"
#include "stm32l4xx.h"
#include <string.h>
#include <stdbool.h>
#include "Timer.h"
void Delay_us(uint32_t us);


#endif // __DELAY_H__
