#include "stm32f10x.h"
#include "stdio.h"
#include "string.h"
#include "uart.h"
#include "led.h"

extern uint8_t emit_status;

void Uart4Init(void)
{
	
	GPIO_InitTypeDef  GPIO_InitStructure;
	USART_InitTypeDef  USART_InitStructure;
	NVIC_InitTypeDef   NVIC_InitStructure;


	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_10 ;  //TX
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_11 ;  //RX
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	
	USART_InitStructure.USART_BaudRate = UART4_BAUD;  
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity =  USART_Parity_No;
    USART_InitStructure.USART_Mode = USART_Mode_Rx |USART_Mode_Tx;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(UART4, &USART_InitStructure);//��ʼ������3
        
	//����3�жϳ�ʼ��
	NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  
  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);

	USART_Cmd(UART4, ENABLE);//ʹ�ܴ���3
	
  	USART_ClearFlag(UART4, USART_FLAG_TC);//�巢����ɱ�־λ

	
}

void Uart1Init(void)
{
	
	GPIO_InitTypeDef  GPIO_InitStructure;
	USART_InitTypeDef  USART_InitStructure;
	NVIC_InitTypeDef   NVIC_InitStructure;


	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_9 ;  //TX
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_10 ;  //RX
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	
	USART_InitStructure.USART_BaudRate = USART1_BAUD;  
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity =  USART_Parity_No;
    USART_InitStructure.USART_Mode = USART_Mode_Rx |USART_Mode_Tx;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(USART1, &USART_InitStructure);//��ʼ������3
        
	//����3�жϳ�ʼ��
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  
  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	

	USART_Cmd(USART1, ENABLE);//ʹ�ܴ���3
	
  	//USART_ClearFlag(USART1, USART_FLAG_TC);//�巢����ɱ�־λ

	
}

void Uart5Init(void)
{
	
	GPIO_InitTypeDef  GPIO_InitStructure;
	USART_InitTypeDef  USART_InitStructure;
	NVIC_InitTypeDef   NVIC_InitStructure;


	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_12 ;  //TX
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_2 ;  //RX
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	
	USART_InitStructure.USART_BaudRate = UART5_BAUD;  
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity =  USART_Parity_No;
    USART_InitStructure.USART_Mode = USART_Mode_Rx |USART_Mode_Tx;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(UART5, &USART_InitStructure);//��ʼ������3
        
	//����3�жϳ�ʼ��
	USART_ITConfig(UART5, USART_IT_RXNE, ENABLE);
	NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;
  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  
  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_Cmd(UART5, ENABLE);//ʹ�ܴ���3
	
  	USART_ClearFlag(UART5, USART_FLAG_TC);//�巢����ɱ�־λ

	
}

void UART4_IRQHandler(void){//With Lora
	if(USART_GetFlagStatus(UART4,USART_FLAG_RXNE)== SET){
		uint16_t receive[2]={0};
		receive[0]=USART_ReceiveData(UART4);
		receive[1]=USART_ReceiveData(UART4);
		//USART_SendData(USART1,receive);//Transpond to CH340
		USART_ClearFlag(UART4,USART_FLAG_RXNE);
		LED1=!LED1;
	}
}

void USART1_IRQHandler(void){//CH340
	if(USART_GetFlagStatus(USART1,USART_FLAG_RXNE)== SET){
		// uint16_t receive=0;
		// receive=USART_ReceiveData(USART1);
		// if(receive==1){
		// 	LED1=0;
		// }
		// else if (receive==2){
		// 	LED1=1;
		// }
	}
}

void UART5_IRQHandler(void){//成功案例 The successful example  External pins
	if(USART_GetFlagStatus(UART5,USART_FLAG_RXNE)== SET){
		uint16_t receive=0;
		receive=USART_ReceiveData(UART5);
		if(receive==1){
			LED1=0;
		}
		else if (receive==2){
			LED1=1;
		}
	}
}

void USART_Send_String(USART_TypeDef *USARTx,uint8_t String[],uint8_t length){
	//uint8_t i=0;
	for(uint8_t i=0;i<length;i++){
		USART_SendData(USARTx,String[i]);
		while(USART_GetFlagStatus(USARTx,USART_FLAG_TXE)==RESET);
	}
}
