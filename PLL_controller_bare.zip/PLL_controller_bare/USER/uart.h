#ifndef __USART_H__
#define __USART_H__

#define UART4_BAUD 115200
#define USART1_BAUD 115200
#define UART5_BAUD 115200

void Uart4Init(void);
void UART4_IRQHandler(void);
void Uart1Init(void);
void USART1_IRQHandler(void);
void Uart5Init(void);
void UART5_IRQHandler(void);
void USART_Send_String(USART_TypeDef *USARTx,uint8_t String[],uint8_t length);

#endif
